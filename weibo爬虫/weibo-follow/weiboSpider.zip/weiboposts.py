import time
import json
from selenium import webdriver
from selenium.webdriver import ActionChains
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys


class GetWeiboPosts:
    browser_options = Options()
    browser_options.add_argument('--disable-gpu')
    browser_options.add_argument("--headless")

    def __init__(self):
        self.driver = webdriver.Chrome(options=self.browser_options)
        self.driver.set_page_load_timeout(100)

    def scraping(self):
        #爬取单个User的
        postsTimes = []
        print("浏览器已成功创建。")

        self.driver.get("https://weibo.com/u/3243433055")

        self.driver.maximize_window()

        time.sleep(8)
        scroll_times = 50  # 滑动次数
        scroll_distance = 5000  # 滑动距离
        wait_time = 10  # 每次滑动后的等待时间

        for _ in range(scroll_times):
            self.driver.execute_script(f"window.scrollBy(0, {scroll_distance});")
            time.sleep(wait_time)
        print(f'微博搜索页面{self.driver.current_url}已成功打开...')
        elems = self.driver.find_elements(by=By.XPATH, value=
        '//div[@class="woo-box-flex woo-box-alignCenter woo-box-justifyCenter head-info_info_2AspQ"]/a[1]')
        for elem in elems:
            postsTimes.append(elem.get_attribute('title'))
            print(elem.get_attribute('title'))

        self.driver.quit()

    def userPosts(self):
        # 补充一下将爬取到的用户ID和时间整理成和Twitter同样的格式
        return

    def getUserName(self):
        # 先找一下有没有UID的大量数据，如果有就直接用，如果没有就自己获取下，转为List[UID1，UID2,。。。]格式，
        return

    def main(self):
        self.scraping()


if __name__ == '__main__':
    gt = GetWeiboPosts()
    gt.main()
