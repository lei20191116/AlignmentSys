import sys

x, y, z, k = map(int, input().split())
print((x + y) * (z - k))